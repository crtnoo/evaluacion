package evaluacion.utiles;

public enum Moneda {
    CARA,
    SECA;

    public static Moneda tirarMoneda() {
        int res = Utiles.random.nextInt(1,3);
        return res == 1 ? CARA : SECA;
    }
}