package evaluacion;

import java.util.ArrayList;
import java.util.List;

import evaluacion.comida.Comida;
import evaluacion.mascotas.Mascota;
import evaluacion.utiles.Moneda;
import evaluacion.utiles.Utiles;

public class Jugador {
    private Mascota mascota;
    private int monedas = 10;

    private List<Comida> comida = new ArrayList<>();

    public Jugador(Mascota mascota) {
        this.mascota = mascota;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public int getMonedas() {
        return monedas;
    }

    public void comprarComida() {
        Comida[] COMIDAS = Comida.values();
        if (monedas < 1) {
            System.out.println("No tenes dinero");
            return;
        }
        System.out.println("Monedas: "+monedas);
        for (int i = 0; i < COMIDAS.length; i++) {
            System.out.println(i + " " + COMIDAS[i].getNombre() + " $"+COMIDAS[i].getPrecio() );
        }
        System.out.println("-1 Salir");
        int opcion = Utiles.ingresarEntero(-1, COMIDAS.length);
        if (opcion == -1) return;
        if (COMIDAS[opcion].getPrecio() > monedas) {
            System.out.println("Es muy caro");
        } else {
            comida.add(COMIDAS[opcion]);
            System.out.println("Compraste " + COMIDAS[opcion].getNombre());
        }
    }
    public void comer() {
        if (comida.size() < 1) {
            System.out.println("No tenes comida");
            return;
        }
        for (int i = 0; i < comida.size(); i++) {
            System.out.println(i + " " + comida.get(i).getNombre());
        }
        System.out.println("-1 Salir");
        int opcion = Utiles.ingresarEntero(-1, comida.size());
        if (opcion == -1) return;
        Comida comerComida = comida.get(opcion);
        mascota.comer(comerComida);
        comida.remove(opcion);
    }

    public void jugar(){
        System.out.println("Elige tu opción:");
        System.out.println("1- Cara");
        System.out.println("2- Seca");
        System.out.println("0- Salir");
        int opcion = Utiles.ingresarEntero(0, 2);
        if (opcion == 0) return;
        Moneda eleccion = opcion == 1 ? Moneda.CARA : Moneda.SECA;
        Moneda resultado = Moneda.tirarMoneda();
        if (eleccion.equals(resultado)) {
            System.out.println("Ganaste");
            monedas += 3;
        } else {
            System.out.println("Perdiste");
        }

        mascota.jugar();
    }

    public void agregarMonedas(int cantidad){
        monedas += cantidad;
    }



}
