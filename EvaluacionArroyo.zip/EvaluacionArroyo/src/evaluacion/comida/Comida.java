package evaluacion.comida;

public enum Comida {

    MANZANA("Manzana", 1,15),
    FIDEOS("Fideos", 5,25),
    SUSHI("Sushi", 10,40);

    private int precio,reduceHambre;
    private String nombre;

    Comida(String nombre, int precioCompra, int reduceHambre) {
        this.nombre = nombre;
        this.precio = precioCompra;
        this.reduceHambre = reduceHambre;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public int getReduceHambre() {
        return reduceHambre;
    }

}
