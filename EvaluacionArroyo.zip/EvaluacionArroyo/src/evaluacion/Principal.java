package evaluacion;

import evaluacion.mascotas.Koi;
import evaluacion.mascotas.Mecca;
import evaluacion.mascotas.Nimmo;
import evaluacion.utiles.Utiles;

public class Principal {

    public static Jugador jugador;

    public static void main(String[] args) {
        System.out.println("Elige tu mascota inicial!");
        System.out.println("1- Nimmo");
        System.out.println("2- Mecca");
        System.out.println("3- Koi");
        int opcion = Utiles.ingresarEntero(1,3);
        if(opcion == 1){
            jugador = new Jugador(new Nimmo());
        }
        else if(opcion == 2) {
        	jugador = new Jugador(new Mecca());
        }
        else {
        	jugador = new Jugador(new Koi());
        }
        System.out.println("Elegiste "+jugador.getMascota().getNombre() + "!");

        boolean salir = false;
        do {
            System.out.println("\n\n");
            salir = mostrarMenu();
        }while(!salir);

        Utiles.s.close();
    }

    private static boolean mostrarMenu() {
    	boolean salir = false;
    	
        jugador.getMascota().mostrarStats();
        System.out.println("Monedas: "+jugador.getMonedas());
        System.out.println("1- Bañar");
        System.out.println("2- Comer");
        System.out.println("3- Dormir");
        System.out.println("4- Jugar");
        System.out.println("5- Comprar comida");
        System.out.println("6- Salir");

        int opcion = Utiles.ingresarEntero(1,6);
        switch (opcion) {
            case 1:
                jugador.getMascota().bañar();
                break;
            case 2:
                jugador.comer();
                break;
            case 3:
                jugador.getMascota().dormir();
                break;
            case 4:
                jugador.jugar();
                break;
            case 5:
                jugador.comprarComida();
                break;
            case 6:
                System.out.println("Saliendo del juego");
                salir = true;
            default:
                System.out.println("Opcion no válida. Por favor, elige una opción del 1 al 6.");
        }
        return salir;
    }
}
