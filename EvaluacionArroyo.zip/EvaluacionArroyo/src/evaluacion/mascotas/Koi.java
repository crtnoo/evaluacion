package evaluacion.mascotas;

public class Koi extends Mascota{
    public Koi() {
        super("Koi", Tipo.AGUA);
    }
}
