package evaluacion.mascotas;

import evaluacion.comida.Comida;

public abstract class Mascota implements MetodosMascota{

    private int suciedad = 0,hambre = 0 ,sueño =  0 ,felicidad = 0;

    private Tipo tipo;
    private String nombre;

    public Mascota(String nombre, Tipo tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }
    public void bañar(){
        suciedad = aumentarFijo(suciedad, -tipo.getLimpieza());
        hambre = aumentarFijo(hambre, 5);
        felicidad = aumentarFijo(felicidad,-7);
    }

    public void comer(Comida comida) {
        hambre = aumentarFijo(hambre, -comida.getReduceHambre());
        suciedad = aumentarFijo(suciedad, 5);
        sueño = aumentarFijo(sueño,7);
    }


    public void dormir(){
        sueño = 0;
    }

    public void jugar() {
        felicidad = aumentarFijo(felicidad, 15);
        suciedad = aumentarFijo(suciedad, 5);
        sueño = aumentarFijo(sueño, 5);
        hambre = aumentarFijo(hambre, 7);
    }

    public int getSuciedad() {
        return suciedad;
    }

    public int getHambre() {
        return hambre;
    }

    public int getSueño() {
        return sueño;
    }

    public int getFelicidad() {
        return felicidad;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public String getNombre() {
        return nombre;
    }

    private int aumentarFijo(int original, int valor){
        int nuevoValor = original + valor;
        if(nuevoValor > 100) return 100;
        else if(nuevoValor < 0) return 0;
        return nuevoValor;
    }

    public void mostrarStats() {
        System.out.println("Estadísticas de la mascota " + nombre + ":");
        System.out.println("Suciedad: " + suciedad);
        System.out.println("Hambre: " + hambre);
        System.out.println("Sueño: " + sueño);
        System.out.println("Felicidad: " + felicidad);
    }
}
