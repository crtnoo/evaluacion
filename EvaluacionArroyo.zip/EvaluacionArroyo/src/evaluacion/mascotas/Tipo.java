package evaluacion.mascotas;

public enum Tipo {
    FUEGO("Fuego", 50),
    AIRE ("Aire",70),
    AGUA("Agua", 90);


    private String nombre;
    private int limpieza;

    Tipo(String nombre, int limpieza) {
        this.nombre = nombre;
        this.limpieza = limpieza;
    }

    public String getNombre() {
        return nombre;
    }

    public int getLimpieza() {
        return limpieza;
    }
}
