package evaluacion.mascotas;

import evaluacion.comida.Comida;

public interface MetodosMascota {
    public void bañar();
    public void comer(Comida comida);
    public void dormir();
    public void jugar();
}
