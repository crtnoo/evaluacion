package evaluacion.mascotas;

public class Mecca extends Mascota{
    public Mecca() {
        super("Mecca", Tipo.AIRE);
    }
}
