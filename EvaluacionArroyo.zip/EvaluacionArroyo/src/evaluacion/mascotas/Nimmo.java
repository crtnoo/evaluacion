package evaluacion.mascotas;

public class Nimmo extends Mascota{

    public Nimmo() {
        super("Nimmo", Tipo.FUEGO);
    }
}
